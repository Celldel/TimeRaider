﻿using UnityEngine;
using System.Collections;

public class Dash : MonoBehaviour {

	//ANVÄNDER INTE LÄNGRE 
//	Vector3[] dashDir;
//	public bool dashing;
//	public bool pressOnce = true;
//	public KeyCode dash = KeyCode.LeftShift;
//	public int dir;
//	public int moveSpeed;
//	// Use this for initialization
//	void Start () {
//		dashDir = new Vector3[] {Vector3.up,-Vector3.up,Vector3.right,-Vector3.right};
//		moveSpeed = GetComponent<MoveBox>().moveSpeed;
//	}
//
//
//	// Update is called once per frame
//
//	void Update () {
//
//		if ( Input.GetKeyDown(dash) && pressOnce ){
//			StartCoroutine(DashTimer());
//		}
//	}
//	void FixedUpdate () {
//	
//
//	}
}
